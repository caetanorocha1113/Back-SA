# Roteiro do vídeo — Back-end (Caetano, grupo 8)

Este arquivo é só para você. Não precisa subir para o GitHub.

## Antes de gravar

1. No back: `npm install`, `npm run build`, `npm run seed`, `npm run dev`.
2. No front: em `.env.development`, deixe `VITE_USE_MOCK=false` e rode `npm run dev`.
3. Abra o `requisicoes.http` no VS Code (extensão REST Client) ou use o Insomnia/Postman.
4. Faça login com a Nicole e cole o `accessToken` na linha `@token` do `requisicoes.http`.

Se o banco antigo já tinha usuários, eles não entram mais, porque agora a senha é salva com hash. Rode o `npm run seed` ou cadastre de novo.

## Sequência (cerca de 5 minutos)

| Etapa | O que mostrar | O que falar |
|---|---|---|
| 1 e 2 | Pasta `src` aberta no VS Code | "Projeto Node com Express. Separei em routes, que define as URLs, controllers, com a lógica, middleware e utils." |
| 3 | `requisicoes.http`: GET, POST e PUT de transações | "Aqui as rotas de leitura, gravação e atualização. O front consome essas mesmas rotas." |
| 4 | Login certo e login com senha errada | "O login devolve um token JWT que expira em 15 minutos e um refresh token. A senha fica no banco com hash bcrypt." Mostre o banco com a senha em `$2b$...`. |
| 5 | GET `/transacoes` sem token (401) e GET `/usuarios` como Nicole (403) | "O middleware `verificarToken` bloqueia quem não está logado. O `permitirPerfis` faz o controle de acesso por perfil: só o admin lista usuários." |
| 6 | GET `/dashboard?periodo=6m` e depois o dashboard no front | "Essa rota soma receitas e despesas por mês e por categoria direto no banco, com `groupBy` e SQL. O front monta os gráficos com ela." |
| 7 | GET `/transacoes?busca=mercado&tipo=despesa&pagina=1&limite=5` | "Filtros por tipo, categoria, status e período, busca por texto, ordenação e paginação." |
| 8 | POST inválido (400), rota que não existe (404) e `errorHandler.js` | "Todos os erros passam por um único middleware e voltam no mesmo formato `{ erro }`. O front mostra essa mensagem no toast." |
| 9 | `schema.prisma` (os `@@index`) e GET `/relatorios` com CSV | "Criei índices por usuário e data para as consultas ficarem rápidas, e uma rota de relatório que também exporta CSV." |
| 10 | `package.json` (scripts `build` e `start`) | "O `build` gera o Prisma Client e aplica as migrations; o `start` roda em produção." |
| 11 | No front: login, criar, editar e excluir uma transação | "Tudo integrado: o que eu cadastro no front vai para o banco pela API." |

## Se perguntarem

- **Por que refresh token?** Para o token de acesso durar pouco. Se ele vazar, perde a validade logo.
- **Por que cada um só vê as próprias transações?** Toda consulta filtra pelo `usuarioId` que vem do token, nunca da URL.
- **Onde está a validação?** Em `utils/validacao.js`. Ela confere o valor maior que zero, o tipo, a categoria certa para o tipo, a data e o status.
